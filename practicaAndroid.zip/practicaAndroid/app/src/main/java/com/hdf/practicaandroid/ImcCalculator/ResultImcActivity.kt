package com.hdf.practicaandroid.ImcCalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.hdf.practicaandroid.ImcCalculator.ImcCalculatorActivity.Companion.IMC_KEY
import com.hdf.practicaandroid.R

class ResultImcActivity : AppCompatActivity() {

    private lateinit var  tvResult:TextView
    private lateinit var  tvImc:TextView
    private lateinit var  tvDescription:TextView
    private lateinit var btnRecalculate: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result_imc)

        val result:Double = intent.extras?.getDouble(IMC_KEY)?: -1.0

        initComponents()
        initUI(result)
        initListeners()
    }

    private fun initListeners() {
        btnRecalculate.setOnClickListener { onBackPressed() }
    }

    private fun initUI(result: Double) {//rango que mide si estas Bajo de peso

        tvImc.text = result.toString()//imc se coloca por fuera del bucle por que siempre va ser llamado
                                      //   sin importar el resultado
        when(result){
            in 0.00..18.50 ->{
                tvResult.text= getString(R.string.title_bajo_peso)
                tvResult.setTextColor(ContextCompat.getColor(this,R.color.peso_bajo))
                tvDescription.text= getString(R.string.description_bajo_peso)
            }
            in 18.51..24.99 ->{//rango que mide si estas con peso normal
                tvResult.text= getString(R.string.title_mormal_peso)
                tvResult.setTextColor(ContextCompat.getColor(this,R.color.peso_normal))
                tvDescription.text= getString(R.string.description_mormal_peso)
            }
            in 25.00..29.99 ->{//rango que mide si estas con sobre peso
                tvResult.text= getString(R.string.title_sobre_peso)
                tvResult.setTextColor(ContextCompat.getColor(this,R.color.sobrepeso))
                tvDescription.text= getString(R.string.description_sobre_peso)
            }
            in 30.00..99.99 ->{//rango que mide si estas obesidad
                tvResult.text= getString(R.string.title_obesidad_peso)
                tvResult.setTextColor(ContextCompat.getColor(this,R.color.obesidad))
                tvDescription.text= getString(R.string.description_obesidad_peso)
            }
            else->{//error
                tvResult.text= getString(R.string.errorResult)
                tvResult.setTextColor(ContextCompat.getColor(this,R.color.obesidad))
                tvDescription.text=getString(R.string.errorDescription)
            }
        }

    }

    private fun initComponents(){
        tvResult = findViewById(R.id.tvResult)
        tvImc= findViewById(R.id.tvImc)
        tvDescription = findViewById(R.id.tvDescription)
        btnRecalculate = findViewById(R.id.btnRecalculate)

    }





}