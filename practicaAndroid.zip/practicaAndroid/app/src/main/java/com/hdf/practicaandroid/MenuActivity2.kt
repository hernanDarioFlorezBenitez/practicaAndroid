package com.hdf.practicaandroid

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.hdf.practicaandroid.ImcCalculator.ImcCalculatorActivity
import com.hdf.practicaandroid.TodoApp.TodoAppActivity
import com.hdf.practicaandroid.settings.SettingsActivity
import com.hdf.practicaandroid.superHeroeapp.SuperHeroeListActivity


class MenuActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu2)

        //codigo para ir del menu a la app de saludo
        val btnSaludoApp = findViewById<Button>(R.id.btnSaludoApp)
        btnSaludoApp.setOnClickListener { navigateToSaludoApp() }

        //codigo para ir del menu a la app de imc
        val btnImcApp = findViewById<Button>(R.id.btnImcApp)
        btnImcApp.setOnClickListener { navigateToImcApp() }

        //codigo para ir del menu a la app de Todo
        val btnTodo =findViewById<Button>(R.id.btnTodo)
        btnTodo.setOnClickListener { navigateToTodoApp() }

    //codigo que nos envia a la app de super heroe
        val btnHeroe = findViewById<Button>(R.id.btnHeroe)
        btnHeroe.setOnClickListener{navigateToSuperHeroe()}

        //codigo que nos enlaza a la app de configuraciones
        val btnSettings = findViewById<Button>(R.id.btnSettings)
        btnSettings.setOnClickListener { navigateToSettings() }

    }

    private fun navigateToSettings() {
        val intent = Intent(this,SettingsActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToSuperHeroe(){
        val intent = Intent(this,SuperHeroeListActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToTodoApp() {
        val intent = Intent(this, TodoAppActivity::class.java)
        startActivity(intent)
    }

    //codigo para ir del menu a la app de saludo
    private fun navigateToSaludoApp() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    //codigo para ir del menu a la app de imc
    private fun navigateToImcApp() {
        val intent = Intent(this, ImcCalculatorActivity::class.java)
        startActivity(intent)
    }


}