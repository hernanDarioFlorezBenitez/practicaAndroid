package com.hdf.practicaandroid.TodoApp

sealed class TaskCategory(var isSelected:Boolean = true) {
    object personal:TaskCategory()
    object Business:TaskCategory()
    object Other:TaskCategory()

}