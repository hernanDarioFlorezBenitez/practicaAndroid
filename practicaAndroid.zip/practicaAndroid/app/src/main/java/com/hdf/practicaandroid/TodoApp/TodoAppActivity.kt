package com.hdf.practicaandroid.TodoApp

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.hdf.practicaandroid.R
import com.hdf.practicaandroid.TodoApp.TaskCategory.*

class TodoAppActivity : AppCompatActivity() {

    private val categories = listOf(
        Business,
        personal,
        Other,
    )

    private val tasks = mutableListOf(
        Task("PruebaBusines", Business),
        Task("PruebaPersonal", personal),
        Task("PruebaOther", Other),
    )

    private lateinit var rvCategories: RecyclerView
    private lateinit var categoryAdapter: CategoryAdapter

    private lateinit var rvTasks:RecyclerView
    private lateinit var tasksAdapter: TasksAdapter
    private lateinit var fabAddTask: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_todo_app)

        initComponent()
        initUI()
        initListeners()

    }

    private fun initListeners() {
        fabAddTask.setOnClickListener {
            updatedTasks()
            showDialog()
        }
    }

    private fun showDialog(){
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_task)

        val btnAddTask: Button = dialog.findViewById(R.id.btnAddTask)
        val etTask: EditText = dialog.findViewById(R.id.etTask)
        val rgCategories: RadioGroup = dialog.findViewById(R.id.rgCategories)

        btnAddTask.setOnClickListener {
            val selectedID = rgCategories.checkedRadioButtonId
            val selectedRadioButton:RadioButton = rgCategories.findViewById(selectedID)
            val currentTask = etTask.text.toString()

            if (currentTask.isNotEmpty()){
                val currentCategory:TaskCategory = when(selectedRadioButton.text){
                    getString(R.string.todo_Radio_busines)-> Business
                    getString(R.string.todo_Radio_personal) -> personal
                    else -> Other
                }
                tasks.add(Task(currentTask,currentCategory))
                updatedTasks()
                dialog.hide()
            }
        }

        dialog.show()
    }

    private fun initComponent() {
        rvCategories= findViewById(R.id.rvCategories)
        rvTasks = findViewById(R.id.rvTasks)
        fabAddTask = findViewById(R.id.fabAddTask)
    }


    private fun initUI() {
        categoryAdapter=CategoryAdapter(categories){updatedCategories(it)}
        rvCategories.layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false)
        rvCategories.adapter = categoryAdapter

        tasksAdapter = TasksAdapter(tasks){onItemSelected(it)}
        rvTasks.layoutManager = LinearLayoutManager(this)
        rvTasks.adapter = tasksAdapter
    }

    private fun onItemSelected(position:Int){
        tasks[position].isSelected = !tasks[position].isSelected
        updatedTasks()
    }

    private fun updatedCategories(position: Int){
        categories[position].isSelected = !categories[position].isSelected
        categoryAdapter.notifyItemChanged(position)
        updatedTasks()
    }

                                //esta funcion le avisa al adaptador que hay nuevos item para que se actualize la vista
    private fun updatedTasks(){
        val selectedCategories: List<TaskCategory> = categories.filter { it.isSelected }
        val newTasks = tasks.filter { selectedCategories.contains(it.category) }
        tasksAdapter.tasks = newTasks
        tasksAdapter.notifyDataSetChanged()
    }



}