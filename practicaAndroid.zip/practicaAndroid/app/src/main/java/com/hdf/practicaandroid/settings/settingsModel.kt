package com.hdf.practicaandroid.settings

import android.os.storage.StorageVolume

data class settingsModel(
    var volume: Int,
    var bluetooth: Boolean,
    var darkMode: Boolean,
    var vibration: Boolean,
    var transmitir: Boolean,
)
