package com.hdf.practicaandroid.superHeroeapp

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {
              //token
    @GET ("/api/10225531303043214/search/{name}")
    suspend fun getSuperHeroes(@Path("name") superHeroeName: String): Response<SuperHeroeDataResponse>

    @GET("/api/10225531303043214/{id}")
    suspend fun getSuperHeroesDetail(@Path("id") superHeroeId: String): Response<SuperHeroeDetailResponse>


}