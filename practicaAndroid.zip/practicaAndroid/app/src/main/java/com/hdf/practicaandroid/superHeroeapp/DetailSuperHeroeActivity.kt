package com.hdf.practicaandroid.superHeroeapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import com.hdf.practicaandroid.R
import com.hdf.practicaandroid.databinding.ActivityDetailSuperHeroeBinding
import com.hdf.practicaandroid.databinding.ActivitySuperHeroeListBinding
import com.squareup.picasso.Picasso
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import kotlin.math.roundToInt

class DetailSuperHeroeActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "extra_id"
    }

    private lateinit var binding: ActivityDetailSuperHeroeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailSuperHeroeBinding.inflate(layoutInflater)
        setContentView(binding.root)


        //recuperacion del id
        val id = intent.getStringExtra(EXTRA_ID).orEmpty()
        getSuperheroeInformation(id)
    }

    private fun getSuperheroeInformation(id: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val superheroeDetail =
                getRetrofit().create(ApiService::class.java).getSuperHeroesDetail(id)

            if (superheroeDetail.body() != null) {
                runOnUiThread { createUI(superheroeDetail.body()!!) }
            }
        }

    }

    private fun createUI(superheroe: SuperHeroeDetailResponse) {
        Picasso.get().load(superheroe.image.url).into(binding.ivSuperheroe)
        binding.tvSuperheroeDetailName.text = superheroe.name
        prepareStats(superheroe.powerstats)
        binding.tvSupheroeRealName.text = superheroe.biography.fullName
        binding.tvPublisher.text = superheroe.biography.publisher
        binding.tvrace.text = superheroe.appearance.race
        binding.tvrelatives.text = superheroe.connections.relatives
    }

    private fun prepareStats(powerstats: powerstatsResponse) {
        updateHeight(binding.vCombat, powerstats.combat)
        updateHeight(binding.vDurability, powerstats.durability)
        updateHeight(binding.vIntelligence, powerstats.intelligence)
        updateHeight(binding.vPower, powerstats.power)
        updateHeight(binding.vSpeed, powerstats.speed)
        updateHeight(binding.vStrength, powerstats.strength)
    }

    private fun updateHeight(view: View, stat: String) {
        val params = view.layoutParams
        params.height = pxToDp(stat.toFloat())
        view.layoutParams = params
    }

    //convertir pixel a medidas dp que usa android
    private fun pxToDp(px: Float): Int {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, px, resources.displayMetrics)
            .roundToInt()
    }


    private fun getRetrofit(): Retrofit {
        return Retrofit
            .Builder()
            .baseUrl("https://superheroapi.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
}

