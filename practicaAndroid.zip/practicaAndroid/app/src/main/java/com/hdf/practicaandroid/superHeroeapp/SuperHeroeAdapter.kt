package com.hdf.practicaandroid.superHeroeapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hdf.practicaandroid.R

class SuperHeroeAdapter(
    var superheroeList: List<SuperHeroeItemResponse> = emptyList(),
    private val onItemSelected: (String) -> Unit
) :
    RecyclerView.Adapter<SuperHeroeViewHolder>() {

    fun updateList(newsuperheroeList: List<SuperHeroeItemResponse>) {
        this.superheroeList = newsuperheroeList
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SuperHeroeViewHolder {

        return SuperHeroeViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_superheroe, parent, false)
        )
    }

    override fun onBindViewHolder(viewholder: SuperHeroeViewHolder, position: Int) {
        viewholder.bind(superheroeList[position],onItemSelected)
    }

    override fun getItemCount() = superheroeList.size
}