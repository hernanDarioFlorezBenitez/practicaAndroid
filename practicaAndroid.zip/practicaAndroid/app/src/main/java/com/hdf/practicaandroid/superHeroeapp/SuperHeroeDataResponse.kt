package com.hdf.practicaandroid.superHeroeapp

import com.google.gson.annotations.SerializedName

//esta la clse que nos trae los datos de la api o base de datos que nos permite tomar sus datos
data class SuperHeroeDataResponse(
    @SerializedName("response") val response:String,
    @SerializedName("results") val superheroes:List<SuperHeroeItemResponse>,
)

data class SuperHeroeItemResponse(
    @SerializedName("id") val superheroeId:String,
    @SerializedName("name") val superheroeName:String,
    @SerializedName("image") val superheroeImage: superheroeImageResponse,
    )

data class superheroeImageResponse(
    @SerializedName("url") val url:String,
)