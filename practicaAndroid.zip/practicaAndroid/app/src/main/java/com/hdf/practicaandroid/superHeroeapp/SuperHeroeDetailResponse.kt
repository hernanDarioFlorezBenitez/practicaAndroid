package com.hdf.practicaandroid.superHeroeapp

import com.google.gson.annotations.SerializedName

data class SuperHeroeDetailResponse(
    @SerializedName("name") val name: String,
    @SerializedName("powerstats") val powerstats: powerstatsResponse,
    @SerializedName("image") val image: superheroeImageDetailResponse,
    @SerializedName("biography") val biography: Biography,
    @SerializedName("connections") val connections: Connections,
    @SerializedName("appearance") val appearance: appearance,

    )

data class powerstatsResponse(
    @SerializedName("intelligence") val intelligence: String,
    @SerializedName("strength") val strength: String,
    @SerializedName("speed") val speed: String,
    @SerializedName("durability") val durability: String,
    @SerializedName("power") val power: String,
    @SerializedName("combat") val combat: String,
)

data class superheroeImageDetailResponse(@SerializedName("url") val url: String)

data class Biography(
    @SerializedName("full-name") val fullName: String,
    @SerializedName("publisher") val publisher: String,
)

data class Connections(
    @SerializedName("relatives") val relatives: String,
)

data class appearance(
    @SerializedName("race") val race: String,
)
// los super heroes y su informacion son sacdos de la APi https://superheroapi.com/
//converson de json a array https://jsoneditoronline.org/#left=local.limaga
