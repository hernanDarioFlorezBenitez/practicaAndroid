package com.hdf.practicaandroid.superHeroeapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.appcompat.widget.SearchView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.hdf.practicaandroid.R
import com.hdf.practicaandroid.databinding.ActivitySuperHeroeListBinding
import com.hdf.practicaandroid.superHeroeapp.DetailSuperHeroeActivity.Companion.EXTRA_ID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class SuperHeroeListActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySuperHeroeListBinding
    private lateinit var retrofit: Retrofit
    private lateinit var adapter: SuperHeroeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySuperHeroeListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        retrofit = getRetrofit()
        initUI()
    }

    private fun initUI() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String?): Boolean {
                searchByName(query.orEmpty())
                return false
            }
            override fun onQueryTextChange(newText: String?) = false
        })

        adapter = SuperHeroeAdapter{superheroeId-> navigationToDetail(superheroeId)}
        binding.rvHeroe.setHasFixedSize(true)
        binding.rvHeroe.layoutManager = LinearLayoutManager(this)
        binding.rvHeroe.adapter = adapter
    }

    private fun searchByName(query: String) {
        binding.progresBar.isVisible = true //activasion del progres bar
        //codigo de corrutinas que permite realizar el llamado de busqueda para luego pintar el layout
        CoroutineScope(Dispatchers.IO).launch {
            val myResponse = retrofit.create(ApiService::class.java).getSuperHeroes(query)

            if (myResponse.isSuccessful){
                Log.i("dario","funciona")

                val response: SuperHeroeDataResponse? = myResponse.body()

                if (response != null){
                    Log.i("dario", response.toString())
                    runOnUiThread{ //esta activa lo que tenga entre las llaves en el hilo principal
                        adapter.updateList(response.superheroes)
                        binding.progresBar.isVisible = false //codigo para quitar el progres bar
                    }

                }

            }else{
                Log.i("dario", "no funciona")
            }
        }
    }

    private fun getRetrofit(): Retrofit {
        return Retrofit
            .Builder()
            .baseUrl("https://superheroapi.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
            //funcion que nos lleva a la activity de detalles del heroe señalado
    private fun navigationToDetail(id:String){
        val intent = Intent(this, DetailSuperHeroeActivity::class.java)
        intent.putExtra(EXTRA_ID,id)
        startActivity(intent)
    }

}



//token de la api que tiene la base de datos de super heroes
//10225531303043214