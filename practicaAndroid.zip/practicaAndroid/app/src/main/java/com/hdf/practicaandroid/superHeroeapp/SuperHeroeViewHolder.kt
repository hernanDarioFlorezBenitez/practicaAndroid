package com.hdf.practicaandroid.superHeroeapp

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.hdf.practicaandroid.databinding.ItemSuperheroeBinding
import com.squareup.picasso.Picasso


class SuperHeroeViewHolder (view: View):RecyclerView.ViewHolder(view){

    private val binding = ItemSuperheroeBinding.bind(view)

    fun  bind(superHeroeItemResponse: SuperHeroeItemResponse,onItemSelected: (String) -> Unit ){
        binding.tvSuperHeroeName.text = superHeroeItemResponse.superheroeName

        Picasso.get().load(superHeroeItemResponse.superheroeImage.url).into(binding.ivSuperheroe)

        binding.root.setOnClickListener{onItemSelected(superHeroeItemResponse.superheroeId)}
    }
}//1:41:31